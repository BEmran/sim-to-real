from setuptools import setup

setup(name='gym_sim_to_real',
      version='0.0.1',
      install_requires=['gym>=0.2.3']
)
