# sim-to-real

# Installation

```bash
cd sim-to-real
pip install -e .
```
