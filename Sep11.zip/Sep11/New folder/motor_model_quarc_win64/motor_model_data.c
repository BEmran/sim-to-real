/*
 * motor_model_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "motor_model".
 *
 * Model version              : 1.35
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Tue Sep 11 17:57:53 2018
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "motor_model.h"
#include "motor_model_private.h"

/* Block parameters (auto storage) */
P_motor_model_T motor_model_P = {
  2.088591925E-5,                      /* Variable: Jeq
                                        * Referenced by: '<S3>/Inertia'
                                        */
  8.4,                                 /* Variable: Rm
                                        * Referenced by: '<S3>/Voltage to  Current'
                                        */
  0.042,                               /* Variable: km
                                        * Referenced by: '<S3>/Back EMF'
                                        */
  0.042,                               /* Variable: kt
                                        * Referenced by: '<S3>/Torque Constant'
                                        */
  3.0,                                 /* Mask Parameter: HILInitialize_analog_input_maxi
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  -3.0,                                /* Mask Parameter: HILInitialize_analog_input_mini
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  15.0,                                /* Mask Parameter: HILInitialize_analog_output_max
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  -15.0,                               /* Mask Parameter: HILInitialize_analog_output_min
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0.0,                                 /* Mask Parameter: StreamClient_default_value
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  0.0,                                 /* Mask Parameter: HILInitialize_final_analog_outp
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */

  /*  Mask Parameter: HILInitialize_final_other_outpu
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 1.0, 0.0, 0.0 },
  0.32258,                             /* Mask Parameter: Slider_gain
                                        * Referenced by: '<S9>/Slider Gain'
                                        */
  0.0,                                 /* Mask Parameter: HILInitialize_initial_analog_ou
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */

  /*  Mask Parameter: HILInitialize_initial_other_out
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0.0, 1.0, 0.0 },
  1.0,                                 /* Mask Parameter: HILInitialize_set_other_outputs
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0.0,                                 /* Mask Parameter: HILInitialize_set_other_outpu_b
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0.0,                                 /* Mask Parameter: HILInitialize_set_other_outp_bh
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1.0,                                 /* Mask Parameter: HILInitialize_set_other_outp_bf
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0.0,                                 /* Mask Parameter: HILInitialize_watchdog_analog_o
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */

  /*  Mask Parameter: HILInitialize_watchdog_other_ou
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0.0, 0.0, 1.0 },
  0,                                   /* Mask Parameter: HILInitialize_hardware_clocks
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_initial_encoder_c
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_watchdog_digital_
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0U,                                  /* Mask Parameter: HILInitialize_analog_input_chan
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0U,                                  /* Mask Parameter: HILInitialize_analog_output_cha
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0U,                                  /* Mask Parameter: HILReadEncoder_channels
                                        * Referenced by: '<S6>/HIL Read Encoder'
                                        */
  0U,                                  /* Mask Parameter: HILWriteAnalog_channels
                                        * Referenced by: '<S7>/HIL Write Analog'
                                        */
  0U,                                  /* Mask Parameter: HILInitialize_digital_output_ch
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */

  /*  Mask Parameter: HILInitialize_encoder_channels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /*  Mask Parameter: HILInitialize_other_output_chan
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 11000U, 11001U, 11002U },
  4U,                                  /* Mask Parameter: HILInitialize_quadrature
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_active
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_final_digital_out
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_initial_digital_o
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_input_
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_inpu_a
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_output
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_outp_j
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_analog_outp_n
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_outp_c
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_analog_outp_h
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_analog_outp_f
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_analog_out_cd
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_clock_frequen
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_clock_frequ_f
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_clock_params_
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_clock_param_o
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_digital_outpu
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_digital_out_m
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_digital_out_b
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_digital_out_i
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_digital_out_g
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_digital_out_f
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_digital_out_a
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_encoder_count
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_encoder_cou_b
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_encoder_param
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_encoder_par_n
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  1,                                   /* Mask Parameter: HILInitialize_set_other_outpu_d
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_outputs_a
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_outputs_j
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_outputs_g
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_outputs_o
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_output_gi
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_params_at
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  0,                                   /* Mask Parameter: HILInitialize_set_pwm_params__n
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  -5.0,                                /* Expression: -5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  0.0030679615757712823,               /* Expression: 2*pi/2048
                                        * Referenced by: '<S6>/Arm: counts to rad'
                                        */

  /*  Expression: [0,0]
   * Referenced by: '<S8>/Integrator'
   */
  { 0.0, 0.0 },
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  -50.0,                               /* Computed Parameter: theta_dot_A
                                        * Referenced by: '<S6>/theta_dot'
                                        */
  -2500.0,                             /* Computed Parameter: theta_dot_C
                                        * Referenced by: '<S6>/theta_dot'
                                        */
  50.0,                                /* Computed Parameter: theta_dot_D
                                        * Referenced by: '<S6>/theta_dot'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S15>/none1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S15>/none2'
                                        */
  4545.0,                              /* Expression: 4545
                                        * Referenced by: '<S15>/termination'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S15>/enable'
                                        */
  57.295779513082323,                  /* Expression: 180/pi
                                        * Referenced by: '<S4>/Gain'
                                        */
  57.295779513082323,                  /* Expression: 180/pi
                                        * Referenced by: '<S5>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/theta_dot'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S7>/For +ve CCW'
                                        */
  0,                                   /* Computed Parameter: StreamClient_SndPriority
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  0,                                   /* Computed Parameter: StreamClient_RcvPriority
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1460U,                               /* Computed Parameter: StreamClient_SndSize
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1460U,                               /* Computed Parameter: StreamClient_RcvSize
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1000U,                               /* Computed Parameter: StreamClient_SndFIFO
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1000U,                               /* Computed Parameter: StreamClient_RcvFIFO
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  2,                                   /* Computed Parameter: StreamClient_Optimize
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  2,                                   /* Computed Parameter: StreamClient_Implementation
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1U,                                  /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<Root>/Manual Switch'
                                        */

  /*  Expression: uri_argument
   * Referenced by: '<S15>/Stream Client'
   */
  { 116U, 99U, 112U, 105U, 112U, 58U, 47U, 47U, 49U, 50U, 55U, 46U, 48U, 46U,
    48U, 46U, 49U, 58U, 49U, 56U, 48U, 48U, 49U, 0U },
  2U,                                  /* Computed Parameter: StreamClient_Endian
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  1U,                                  /* Computed Parameter: ManualSwitch1_CurrentSetting
                                        * Referenced by: '<Root>/Manual Switch1'
                                        */
  1,                                   /* Computed Parameter: HILReadEncoder_Active
                                        * Referenced by: '<S6>/HIL Read Encoder'
                                        */
  0,                                   /* Computed Parameter: StreamClient_Active
                                        * Referenced by: '<S15>/Stream Client'
                                        */
  0                                    /* Computed Parameter: HILWriteAnalog_Active
                                        * Referenced by: '<S7>/HIL Write Analog'
                                        */
};
