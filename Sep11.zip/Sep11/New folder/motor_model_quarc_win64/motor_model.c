/*
 * motor_model.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "motor_model".
 *
 * Model version              : 1.35
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Tue Sep 11 17:57:53 2018
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "motor_model.h"
#include "motor_model_private.h"
#include "motor_model_dt.h"

/* Block signals (auto storage) */
B_motor_model_T motor_model_B;

/* Continuous states */
X_motor_model_T motor_model_X;

/* Block states (auto storage) */
DW_motor_model_T motor_model_DW;

/* Real-time model */
RT_MODEL_motor_model_T motor_model_M_;
RT_MODEL_motor_model_T *const motor_model_M = &motor_model_M_;

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  motor_model_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; i++) {
    *x += h * f0[i];
    x++;
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void motor_model_output(void)
{
  /* local block i/o variables */
  real_T rtb_TmpSignalConversionAtStream[6];
  real_T rtb_ForveCCW;
  real_T rtb_SliderGain;
  if (rtmIsMajorTimeStep(motor_model_M)) {
    /* set solver stop time */
    if (!(motor_model_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&motor_model_M->solverInfo,
                            ((motor_model_M->Timing.clockTickH0 + 1) *
        motor_model_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&motor_model_M->solverInfo,
                            ((motor_model_M->Timing.clockTick0 + 1) *
        motor_model_M->Timing.stepSize0 + motor_model_M->Timing.clockTickH0 *
        motor_model_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(motor_model_M)) {
    motor_model_M->Timing.t[0] = rtsiGetT(&motor_model_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(motor_model_M)) {
    /* S-Function (hil_read_encoder_block): '<S6>/HIL Read Encoder' */

    /* S-Function Block: motor_model/Read Angles/HIL Read Encoder (hil_read_encoder_block) */
    {
      t_error result = hil_read_encoder(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILReadEncoder_channels, 1,
        &motor_model_DW.HILReadEncoder_Buffer);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
      } else {
        rtb_ForveCCW = motor_model_DW.HILReadEncoder_Buffer;
      }
    }

    /* Gain: '<S6>/Arm: counts to rad' */
    motor_model_B.theta = motor_model_P.Armcountstorad_Gain * rtb_ForveCCW;

    /* Gain: '<S9>/Slider Gain' incorporates:
     *  Constant: '<Root>/Constant'
     */
    rtb_SliderGain = motor_model_P.Slider_gain * motor_model_P.Constant_Value;
  }

  /* Clock: '<S15>/Clock' */
  motor_model_B.Clock = motor_model_M->Timing.t[0];

  /* TransferFcn: '<S6>/theta_dot' */
  motor_model_B.w = 0.0;
  motor_model_B.w += motor_model_P.theta_dot_C * motor_model_X.theta_dot_CSTATE;
  motor_model_B.w += motor_model_P.theta_dot_D * motor_model_B.theta;
  if (rtmIsMajorTimeStep(motor_model_M)) {
    /* SignalConversion: '<S15>/TmpSignal ConversionAtStream ClientInport1' incorporates:
     *  Constant: '<S15>/none1'
     *  Constant: '<S15>/none2'
     *  Constant: '<S15>/termination'
     */
    rtb_TmpSignalConversionAtStream[0] = motor_model_B.Clock;
    rtb_TmpSignalConversionAtStream[1] = motor_model_B.theta;
    rtb_TmpSignalConversionAtStream[2] = motor_model_B.w;
    rtb_TmpSignalConversionAtStream[3] = motor_model_P.none1_Value;
    rtb_TmpSignalConversionAtStream[4] = motor_model_P.none2_Value;
    rtb_TmpSignalConversionAtStream[5] = motor_model_P.termination_Value;

    /* S-Function (stream_client_block): '<S15>/Stream Client' */

    /* S-Function Block: motor_model/Connection/TCP connection/Stream Client (stream_client_block) */
    {
      t_pstream_state state;
      t_error send_result;
      t_error receive_result;
      if (motor_model_P.enable_Value) {
        send_result = pstream_send(motor_model_DW.StreamClient_Stream,
          &rtb_TmpSignalConversionAtStream[0]);
      } else {
        send_result = 0;
      }

      receive_result = pstream_receive(motor_model_DW.StreamClient_Stream,
        &motor_model_B.StreamClient_o4);
      pstream_get_state(motor_model_DW.StreamClient_Stream, &state);
    }

    /* ManualSwitch: '<Root>/Manual Switch1' */
    if (motor_model_P.ManualSwitch1_CurrentSetting == 1) {
      /* ManualSwitch: '<Root>/Manual Switch' incorporates:
       *  Saturate: '<Root>/Saturation'
       */
      if (motor_model_P.ManualSwitch_CurrentSetting == 1) {
        motor_model_B.ManualSwitch1 = rtb_SliderGain;
      } else if (motor_model_B.StreamClient_o4 >
                 motor_model_P.Saturation_UpperSat) {
        /* Saturate: '<Root>/Saturation' */
        motor_model_B.ManualSwitch1 = motor_model_P.Saturation_UpperSat;
      } else if (motor_model_B.StreamClient_o4 <
                 motor_model_P.Saturation_LowerSat) {
        /* Saturate: '<Root>/Saturation' */
        motor_model_B.ManualSwitch1 = motor_model_P.Saturation_LowerSat;
      } else {
        /* Saturate: '<Root>/Saturation' */
        motor_model_B.ManualSwitch1 = motor_model_B.StreamClient_o4;
      }

      /* End of ManualSwitch: '<Root>/Manual Switch' */
    } else {
      motor_model_B.ManualSwitch1 = 0.0;
    }

    /* End of ManualSwitch: '<Root>/Manual Switch1' */
  }

  /* MATLAB Function: '<S8>/MATLAB Function' incorporates:
   *  Integrator: '<S8>/Integrator'
   */
  /* MATLAB Function 'Simulation/MATLAB Function': '<S16>:1' */
  /*  Resistance */
  /*  Current-torque (N-m/A) */
  /*  Back-emf constant (V-s/rad) */
  /*  Rotor inertia (kg-m^2) */
  /*  9 g Hub mass (kg) */
  /*  Hub radius (m) diameter 22.2 mm */
  /*  Hub inertia (kg-m^2) */
  /*  Disc mass (kg) */
  /*  Disc radius (m) diameter = 49.5 mm */
  /*  Disc moment of inertia (kg-m^2) */
  /*  Equivalent moment of inertia (kg-m^2) */
  /* '<S16>:1:16' */
  /* '<S16>:1:19' */
  /* '<S16>:1:21' */
  motor_model_B.xdot[0] = motor_model_X.Integrator_CSTATE[1];
  motor_model_B.xdot[1] = (-motor_model_B.ManualSwitch1 - 0.042 *
    motor_model_X.Integrator_CSTATE[1]) * 0.042 / 8.4 / 2.088591925E-5;

  /* Gain: '<S4>/Gain' */
  motor_model_B.Gain[0] = motor_model_P.Gain_Gain * motor_model_B.theta;
  motor_model_B.Gain[1] = motor_model_P.Gain_Gain * motor_model_B.xdot[0];

  /* Gain: '<S5>/Gain' */
  motor_model_B.Gain_e[0] = motor_model_P.Gain_Gain_a * motor_model_B.w;
  motor_model_B.Gain_e[1] = motor_model_P.Gain_Gain_a * motor_model_B.xdot[0];
  if (rtmIsMajorTimeStep(motor_model_M)) {
  }

  /* Integrator: '<S3>/theta_dot' */
  motor_model_B.theta_dot = motor_model_X.theta_dot_CSTATE_b;
  if (rtmIsMajorTimeStep(motor_model_M)) {
    /* Gain: '<S7>/For +ve CCW' */
    rtb_ForveCCW = motor_model_P.ForveCCW_Gain * motor_model_B.ManualSwitch1;

    /* S-Function (hil_write_analog_block): '<S7>/HIL Write Analog' */

    /* S-Function Block: motor_model/Send Voltage/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILWriteAnalog_channels, 1, &rtb_ForveCCW);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
      }
    }

    /* UnaryMinus: '<S3>/For +ve CCW' */
    motor_model_B.ForveCCW = -motor_model_B.ManualSwitch1;
  }

  /* Gain: '<S3>/Inertia' incorporates:
   *  Gain: '<S3>/Back EMF'
   *  Gain: '<S3>/Torque Constant'
   *  Gain: '<S3>/Voltage to  Current'
   *  Sum: '<S3>/Sum'
   */
  motor_model_B.Inertia = (motor_model_B.ForveCCW - motor_model_P.km *
    motor_model_B.theta_dot) * (1.0 / motor_model_P.Rm) * motor_model_P.kt *
    (1.0 / motor_model_P.Jeq);
}

/* Model update function */
void motor_model_update(void)
{
  if (rtmIsMajorTimeStep(motor_model_M)) {
    rt_ertODEUpdateContinuousStates(&motor_model_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++motor_model_M->Timing.clockTick0)) {
    ++motor_model_M->Timing.clockTickH0;
  }

  motor_model_M->Timing.t[0] = rtsiGetSolverStopTime(&motor_model_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.002s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++motor_model_M->Timing.clockTick1)) {
      ++motor_model_M->Timing.clockTickH1;
    }

    motor_model_M->Timing.t[1] = motor_model_M->Timing.clockTick1 *
      motor_model_M->Timing.stepSize1 + motor_model_M->Timing.clockTickH1 *
      motor_model_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void motor_model_derivatives(void)
{
  XDot_motor_model_T *_rtXdot;
  _rtXdot = ((XDot_motor_model_T *) motor_model_M->ModelData.derivs);

  /* Derivatives for Integrator: '<S8>/Integrator' */
  _rtXdot->Integrator_CSTATE[0] = motor_model_B.xdot[0];
  _rtXdot->Integrator_CSTATE[1] = motor_model_B.xdot[1];

  /* Derivatives for TransferFcn: '<S6>/theta_dot' */
  _rtXdot->theta_dot_CSTATE = 0.0;
  _rtXdot->theta_dot_CSTATE += motor_model_P.theta_dot_A *
    motor_model_X.theta_dot_CSTATE;
  _rtXdot->theta_dot_CSTATE += motor_model_B.theta;

  /* Derivatives for Integrator: '<S3>/theta_dot' */
  _rtXdot->theta_dot_CSTATE_b = motor_model_B.Inertia;
}

/* Model initialize function */
void motor_model_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: motor_model/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("qube_servo2_usb", "0", &motor_model_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_model_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_watchdog_clear(motor_model_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_model_M, _rt_error_message);
      return;
    }

    if ((motor_model_P.HILInitialize_set_analog_input_ && !is_switching) ||
        (motor_model_P.HILInitialize_set_analog_inpu_a && is_switching)) {
      result = hil_set_analog_input_ranges(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILInitialize_analog_input_chan, 1U,
        &motor_model_P.HILInitialize_analog_input_mini,
        &motor_model_P.HILInitialize_analog_input_maxi);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if ((motor_model_P.HILInitialize_set_analog_output && !is_switching) ||
        (motor_model_P.HILInitialize_set_analog_outp_j && is_switching)) {
      result = hil_set_analog_output_ranges(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILInitialize_analog_output_cha, 1U,
        &motor_model_P.HILInitialize_analog_output_min,
        &motor_model_P.HILInitialize_analog_output_max);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if ((motor_model_P.HILInitialize_set_analog_outp_n && !is_switching) ||
        (motor_model_P.HILInitialize_set_analog_outp_c && is_switching)) {
      result = hil_write_analog(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILInitialize_analog_output_cha, 1U,
        &motor_model_P.HILInitialize_initial_analog_ou);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if (motor_model_P.HILInitialize_set_analog_out_cd) {
      result = hil_watchdog_set_analog_expiration_state
        (motor_model_DW.HILInitialize_Card,
         &motor_model_P.HILInitialize_analog_output_cha, 1U,
         &motor_model_P.HILInitialize_watchdog_analog_o);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    result = hil_set_digital_directions(motor_model_DW.HILInitialize_Card, NULL,
      0U, &motor_model_P.HILInitialize_digital_output_ch, 1U);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_model_M, _rt_error_message);
      return;
    }

    if ((motor_model_P.HILInitialize_set_digital_out_b && !is_switching) ||
        (motor_model_P.HILInitialize_set_digital_out_i && is_switching)) {
      result = hil_write_digital(motor_model_DW.HILInitialize_Card,
        &motor_model_P.HILInitialize_digital_output_ch, 1U, (t_boolean *)
        &motor_model_P.HILInitialize_initial_digital_o);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if (motor_model_P.HILInitialize_set_digital_out_a) {
      result = hil_watchdog_set_digital_expiration_state
        (motor_model_DW.HILInitialize_Card,
         &motor_model_P.HILInitialize_digital_output_ch, 1U, (const
          t_digital_state *) &motor_model_P.HILInitialize_watchdog_digital_);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if ((motor_model_P.HILInitialize_set_encoder_param && !is_switching) ||
        (motor_model_P.HILInitialize_set_encoder_par_n && is_switching)) {
      motor_model_DW.HILInitialize_QuadratureModes[0] =
        motor_model_P.HILInitialize_quadrature;
      motor_model_DW.HILInitialize_QuadratureModes[1] =
        motor_model_P.HILInitialize_quadrature;
      result = hil_set_encoder_quadrature_mode(motor_model_DW.HILInitialize_Card,
        motor_model_P.HILInitialize_encoder_channels, 2U,
        (t_encoder_quadrature_mode *)
        &motor_model_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if ((motor_model_P.HILInitialize_set_encoder_count && !is_switching) ||
        (motor_model_P.HILInitialize_set_encoder_cou_b && is_switching)) {
      motor_model_DW.HILInitialize_InitialEICounts[0] =
        motor_model_P.HILInitialize_initial_encoder_c;
      motor_model_DW.HILInitialize_InitialEICounts[1] =
        motor_model_P.HILInitialize_initial_encoder_c;
      result = hil_set_encoder_counts(motor_model_DW.HILInitialize_Card,
        motor_model_P.HILInitialize_encoder_channels, 2U,
        &motor_model_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if ((motor_model_P.HILInitialize_set_other_outputs && !is_switching) ||
        (motor_model_P.HILInitialize_set_other_outpu_b && is_switching)) {
      result = hil_write_other(motor_model_DW.HILInitialize_Card,
        motor_model_P.HILInitialize_other_output_chan, 3U,
        motor_model_P.HILInitialize_initial_other_out);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }

    if (motor_model_P.HILInitialize_set_other_outpu_d) {
      result = hil_watchdog_set_other_expiration_state
        (motor_model_DW.HILInitialize_Card,
         motor_model_P.HILInitialize_other_output_chan, 3U,
         motor_model_P.HILInitialize_watchdog_other_ou);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (stream_client_block): '<S15>/Stream Client' */

  /* S-Function Block: motor_model/Connection/TCP connection/Stream Client (stream_client_block) */
  {
    qthread_attr_t send_thread_attributes;
    qthread_attr_t receive_thread_attributes;
    struct qsched_param scheduling_parameters;
    int min_priority = qsched_get_priority_min(QSCHED_FIFO);
    int max_priority = qsched_get_priority_max(QSCHED_FIFO);
    t_pstream_options options;
    t_error result;
    motor_model_DW.StreamClient_Stream = NULL;
    motor_model_B.StreamClient_o4 = motor_model_P.StreamClient_default_value;
    result = 0;
    options.size = sizeof(options);
    options.flags = motor_model_P.StreamClient_Endian & PSTREAM_FLAG_ENDIAN_MASK;
    if (motor_model_P.StreamClient_Implementation ==
        STREAM_CLIENT_IMPLEMENTATION_THREAD) {
      options.flags |= PSTREAM_FLAG_MULTITHREADED;
    }

    if (motor_model_P.StreamClient_Optimize == STREAM_CLIENT_OPTIMIZE_LATENCY) {
      options.flags |= PSTREAM_FLAG_MINIMIZE_LATENCY;
    }

    options.flags |= PSTREAM_FLAG_SEND_MOST_RECENT;
    options.flags |= PSTREAM_FLAG_RECEIVE_MOST_RECENT;
    options.send_unit_size = 8;
    options.num_send_units = 6;
    options.send_buffer_size = motor_model_P.StreamClient_SndSize;
    options.send_fifo_size = motor_model_P.StreamClient_SndFIFO;
    options.num_send_dimensions = 0;
    options.max_send_dimensions = NULL;
    if (motor_model_P.StreamClient_SndPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (motor_model_P.StreamClient_SndPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        motor_model_P.StreamClient_SndPriority;
    }

    qthread_attr_init(&send_thread_attributes);
    result = qthread_attr_setschedpolicy(&send_thread_attributes, QSCHED_FIFO);
    if (result == 0) {
      result = qthread_attr_setschedparam(&send_thread_attributes,
        &scheduling_parameters);
      if (result == 0) {
        result = qthread_attr_setinheritsched(&send_thread_attributes,
          QTHREAD_EXPLICIT_SCHED);
        if (result < 0) {
          rtmSetErrorStatus(motor_model_M,
                            "Unable to set scheduling inheritance for Stream Client sending thread");
        }
      } else {
        rtmSetErrorStatus(motor_model_M,
                          "The specified thread priority for the Stream Client sending thread is not valid for this target");
      }
    } else {
      rtmSetErrorStatus(motor_model_M,
                        "Unable to set scheduling policy for Stream Client sending thread");
    }

    options.send_thread_attributes = &send_thread_attributes;
    options.receive_unit_size = 8;
    options.num_receive_units = 1;
    options.receive_buffer_size = motor_model_P.StreamClient_RcvSize;
    options.receive_fifo_size = motor_model_P.StreamClient_RcvFIFO;
    options.num_receive_dimensions = 0;
    options.max_receive_dimensions = NULL;
    if (motor_model_P.StreamClient_RcvPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (motor_model_P.StreamClient_RcvPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        motor_model_P.StreamClient_RcvPriority;
    }

    qthread_attr_init(&receive_thread_attributes);
    if (result == 0) {
      result = qthread_attr_setschedpolicy(&receive_thread_attributes,
        QSCHED_FIFO);
      if (result == 0) {
        result = qthread_attr_setschedparam(&receive_thread_attributes,
          &scheduling_parameters);
        if (result == 0) {
          result = qthread_attr_setinheritsched(&receive_thread_attributes,
            QTHREAD_EXPLICIT_SCHED);
          if (result < 0) {
            rtmSetErrorStatus(motor_model_M,
                              "Unable to set scheduling inheritance for Stream Client receiving thread");
          }
        } else {
          rtmSetErrorStatus(motor_model_M,
                            "The specified thread priority for the Stream Client receiving thread is not valid for this target");
        }
      } else {
        rtmSetErrorStatus(motor_model_M,
                          "Unable to set scheduling policy for Stream Client receiving thread");
      }
    }

    options.receive_thread_attributes = &receive_thread_attributes;
    if (result == 0) {
      result = pstream_connect((const char *) motor_model_P.StreamClient_URI,
        &options, &motor_model_DW.StreamClient_Stream);
      if (result < 0 && result != -QERR_WOULD_BLOCK) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_model_M, _rt_error_message);
      }
    }

    qthread_attr_destroy(&send_thread_attributes);
    qthread_attr_destroy(&receive_thread_attributes);
  }

  /* InitializeConditions for Integrator: '<S8>/Integrator' */
  motor_model_X.Integrator_CSTATE[0] = motor_model_P.Integrator_IC[0];
  motor_model_X.Integrator_CSTATE[1] = motor_model_P.Integrator_IC[1];

  /* InitializeConditions for TransferFcn: '<S6>/theta_dot' */
  motor_model_X.theta_dot_CSTATE = 0.0;

  /* InitializeConditions for Integrator: '<S3>/theta_dot' */
  motor_model_X.theta_dot_CSTATE_b = motor_model_P.theta_dot_IC;
}

/* Model terminate function */
void motor_model_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: motor_model/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_digital_outputs = 0;
    t_uint32 num_final_other_outputs = 0;
    hil_task_stop_all(motor_model_DW.HILInitialize_Card);
    hil_monitor_stop_all(motor_model_DW.HILInitialize_Card);
    is_switching = false;
    if ((motor_model_P.HILInitialize_set_analog_outp_f && !is_switching) ||
        (motor_model_P.HILInitialize_set_analog_outp_h && is_switching)) {
      num_final_analog_outputs = 1U;
    }

    if ((motor_model_P.HILInitialize_set_digital_out_f && !is_switching) ||
        (motor_model_P.HILInitialize_set_digital_out_g && is_switching)) {
      num_final_digital_outputs = 1U;
    }

    if ((motor_model_P.HILInitialize_set_other_outp_bf && !is_switching) ||
        (motor_model_P.HILInitialize_set_other_outp_bh && is_switching)) {
      num_final_other_outputs = 3U;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_digital_outputs > 0
        || num_final_other_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(motor_model_DW.HILInitialize_Card
                         , &motor_model_P.HILInitialize_analog_output_cha,
                         num_final_analog_outputs
                         , NULL, 0
                         , &motor_model_P.HILInitialize_digital_output_ch,
                         num_final_digital_outputs
                         , motor_model_P.HILInitialize_other_output_chan,
                         num_final_other_outputs
                         , &motor_model_P.HILInitialize_final_analog_outp
                         , NULL
                         , (t_boolean *)
                         &motor_model_P.HILInitialize_final_digital_out
                         , motor_model_P.HILInitialize_final_other_outpu
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(motor_model_DW.HILInitialize_Card,
            &motor_model_P.HILInitialize_analog_output_cha,
            num_final_analog_outputs,
            &motor_model_P.HILInitialize_final_analog_outp);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_digital_outputs > 0) {
          local_result = hil_write_digital(motor_model_DW.HILInitialize_Card,
            &motor_model_P.HILInitialize_digital_output_ch,
            num_final_digital_outputs, (t_boolean *)
            &motor_model_P.HILInitialize_final_digital_out);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_other_outputs > 0) {
          local_result = hil_write_other(motor_model_DW.HILInitialize_Card,
            motor_model_P.HILInitialize_other_output_chan,
            num_final_other_outputs,
            motor_model_P.HILInitialize_final_other_outpu);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(motor_model_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(motor_model_DW.HILInitialize_Card);
    hil_monitor_delete_all(motor_model_DW.HILInitialize_Card);
    hil_close(motor_model_DW.HILInitialize_Card);
    motor_model_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for S-Function (stream_client_block): '<S15>/Stream Client' */

  /* S-Function Block: motor_model/Connection/TCP connection/Stream Client (stream_client_block) */
  {
    if (motor_model_DW.StreamClient_Stream != NULL) {
      pstream_close(motor_model_DW.StreamClient_Stream);
    }

    motor_model_DW.StreamClient_Stream = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  motor_model_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  motor_model_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  motor_model_initialize();
}

void MdlTerminate(void)
{
  motor_model_terminate();
}

/* Registration function */
RT_MODEL_motor_model_T *motor_model(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)motor_model_M, 0,
                sizeof(RT_MODEL_motor_model_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&motor_model_M->solverInfo,
                          &motor_model_M->Timing.simTimeStep);
    rtsiSetTPtr(&motor_model_M->solverInfo, &rtmGetTPtr(motor_model_M));
    rtsiSetStepSizePtr(&motor_model_M->solverInfo,
                       &motor_model_M->Timing.stepSize0);
    rtsiSetdXPtr(&motor_model_M->solverInfo, &motor_model_M->ModelData.derivs);
    rtsiSetContStatesPtr(&motor_model_M->solverInfo, (real_T **)
                         &motor_model_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&motor_model_M->solverInfo,
      &motor_model_M->Sizes.numContStates);
    rtsiSetErrorStatusPtr(&motor_model_M->solverInfo, (&rtmGetErrorStatus
      (motor_model_M)));
    rtsiSetRTModelPtr(&motor_model_M->solverInfo, motor_model_M);
  }

  rtsiSetSimTimeStep(&motor_model_M->solverInfo, MAJOR_TIME_STEP);
  motor_model_M->ModelData.intgData.f[0] = motor_model_M->ModelData.odeF[0];
  motor_model_M->ModelData.contStates = ((real_T *) &motor_model_X);
  rtsiSetSolverData(&motor_model_M->solverInfo, (void *)
                    &motor_model_M->ModelData.intgData);
  rtsiSetSolverName(&motor_model_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = motor_model_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    motor_model_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    motor_model_M->Timing.sampleTimes = (&motor_model_M->
      Timing.sampleTimesArray[0]);
    motor_model_M->Timing.offsetTimes = (&motor_model_M->
      Timing.offsetTimesArray[0]);

    /* task periods */
    motor_model_M->Timing.sampleTimes[0] = (0.0);
    motor_model_M->Timing.sampleTimes[1] = (0.002);

    /* task offsets */
    motor_model_M->Timing.offsetTimes[0] = (0.0);
    motor_model_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(motor_model_M, &motor_model_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = motor_model_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    motor_model_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(motor_model_M, -1);
  motor_model_M->Timing.stepSize0 = 0.002;
  motor_model_M->Timing.stepSize1 = 0.002;

  /* External mode info */
  motor_model_M->Sizes.checksums[0] = (295162734U);
  motor_model_M->Sizes.checksums[1] = (1721841536U);
  motor_model_M->Sizes.checksums[2] = (2063130796U);
  motor_model_M->Sizes.checksums[3] = (4278327522U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[4];
    motor_model_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(motor_model_M->extModeInfo,
      &motor_model_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(motor_model_M->extModeInfo,
                        motor_model_M->Sizes.checksums);
    rteiSetTPtr(motor_model_M->extModeInfo, rtmGetTPtr(motor_model_M));
  }

  motor_model_M->solverInfoPtr = (&motor_model_M->solverInfo);
  motor_model_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&motor_model_M->solverInfo, 0.002);
  rtsiSetSolverMode(&motor_model_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  motor_model_M->ModelData.blockIO = ((void *) &motor_model_B);
  (void) memset(((void *) &motor_model_B), 0,
                sizeof(B_motor_model_T));

  /* parameters */
  motor_model_M->ModelData.defaultParam = ((real_T *)&motor_model_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &motor_model_X;
    motor_model_M->ModelData.contStates = (x);
    (void) memset((void *)&motor_model_X, 0,
                  sizeof(X_motor_model_T));
  }

  /* states (dwork) */
  motor_model_M->ModelData.dwork = ((void *) &motor_model_DW);
  (void) memset((void *)&motor_model_DW, 0,
                sizeof(DW_motor_model_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    motor_model_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  motor_model_M->Sizes.numContStates = (4);/* Number of continuous states */
  motor_model_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  motor_model_M->Sizes.numY = (0);     /* Number of model outputs */
  motor_model_M->Sizes.numU = (0);     /* Number of model inputs */
  motor_model_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  motor_model_M->Sizes.numSampTimes = (2);/* Number of sample times */
  motor_model_M->Sizes.numBlocks = (36);/* Number of blocks */
  motor_model_M->Sizes.numBlockIO = (11);/* Number of block outputs */
  motor_model_M->Sizes.numBlockPrms = (130);/* Sum of parameter "widths" */
  return motor_model_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
