/*
 * motor_ident.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "motor_ident".
 *
 * Model version              : 1.40
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Tue Sep 11 18:35:22 2018
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "motor_ident.h"
#include "motor_ident_private.h"
#include "motor_ident_dt.h"

/* Block signals (auto storage) */
B_motor_ident_T motor_ident_B;

/* Continuous states */
X_motor_ident_T motor_ident_X;

/* Block states (auto storage) */
DW_motor_ident_T motor_ident_DW;

/* Real-time model */
RT_MODEL_motor_ident_T motor_ident_M_;
RT_MODEL_motor_ident_T *const motor_ident_M = &motor_ident_M_;

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  motor_ident_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; i++) {
    *x += h * f0[i];
    x++;
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void motor_ident_output(void)
{
  /* local block i/o variables */
  real_T rtb_FromWs;
  real_T rtb_HILReadEncoder;
  if (rtmIsMajorTimeStep(motor_ident_M)) {
    /* set solver stop time */
    if (!(motor_ident_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&motor_ident_M->solverInfo,
                            ((motor_ident_M->Timing.clockTickH0 + 1) *
        motor_ident_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&motor_ident_M->solverInfo,
                            ((motor_ident_M->Timing.clockTick0 + 1) *
        motor_ident_M->Timing.stepSize0 + motor_ident_M->Timing.clockTickH0 *
        motor_ident_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(motor_ident_M)) {
    motor_ident_M->Timing.t[0] = rtsiGetT(&motor_ident_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(motor_ident_M)) {
    /* S-Function (hil_read_encoder_block): '<S2>/HIL Read Encoder' */

    /* S-Function Block: motor_ident/Read Angles/HIL Read Encoder (hil_read_encoder_block) */
    {
      t_error result = hil_read_encoder(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILReadEncoder_channels, 1,
        &motor_ident_DW.HILReadEncoder_Buffer);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      } else {
        rtb_HILReadEncoder = motor_ident_DW.HILReadEncoder_Buffer;
      }
    }

    /* Gain: '<S2>/Arm: counts to rad' */
    motor_ident_B.theta = motor_ident_P.Armcountstorad_Gain * rtb_HILReadEncoder;

    /* Gain: '<S1>/Gain' */
    motor_ident_B.Gain = motor_ident_P.Gain_Gain * motor_ident_B.theta;
  }

  /* TransferFcn: '<S2>/theta_dot' */
  motor_ident_B.w = 0.0;
  motor_ident_B.w += motor_ident_P.theta_dot_C * motor_ident_X.theta_dot_CSTATE;
  motor_ident_B.w += motor_ident_P.theta_dot_D * motor_ident_B.theta;

  /* TransferFcn: '<Root>/Transfer Fcn' */
  motor_ident_B.TransferFcn = 0.0;
  motor_ident_B.TransferFcn += motor_ident_P.TransferFcn_C *
    motor_ident_X.TransferFcn_CSTATE;
  if (rtmIsMajorTimeStep(motor_ident_M)) {
    /* Gain: '<S5>/Slider Gain' incorporates:
     *  Constant: '<Root>/Constant'
     */
    motor_ident_B.SliderGain = motor_ident_P.Slider_gain *
      motor_ident_P.Constant_Value;
  }

  /* FromWorkspace: '<S4>/FromWs' */
  {
    real_T *pDataValues = (real_T *) motor_ident_DW.FromWs_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) motor_ident_DW.FromWs_PWORK.TimePtr;
    int_T currTimeIndex = motor_ident_DW.FromWs_IWORK.PrevIndex;
    real_T t = motor_ident_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[99]) {
      currTimeIndex = 98;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    motor_ident_DW.FromWs_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_FromWs = pDataValues[currTimeIndex];
        } else {
          rtb_FromWs = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_FromWs = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 100;
      }
    }
  }

  /* ManualSwitch: '<Root>/Manual Switch' */
  if (motor_ident_P.ManualSwitch_CurrentSetting == 1) {
    motor_ident_B.ManualSwitch = motor_ident_B.SliderGain;
  } else {
    motor_ident_B.ManualSwitch = rtb_FromWs;
  }

  /* End of ManualSwitch: '<Root>/Manual Switch' */

  /* Gain: '<S3>/For +ve CCW' */
  motor_ident_B.ForveCCW = motor_ident_P.ForveCCW_Gain *
    motor_ident_B.ManualSwitch;
  if (rtmIsMajorTimeStep(motor_ident_M)) {
    /* S-Function (hil_write_analog_block): '<S3>/HIL Write Analog' */

    /* S-Function Block: motor_ident/Send Voltage/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILWriteAnalog_channels, 1, &motor_ident_B.ForveCCW);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      }
    }
  }

  /* Clock: '<Root>/Clock' */
  motor_ident_B.Clock = motor_ident_M->Timing.t[0];
  if (rtmIsMajorTimeStep(motor_ident_M)) {
    /* SignalConversion: '<Root>/TmpSignal ConversionAtTo WorkspaceInport1' */
    motor_ident_B.TmpSignalConversionAtToWorkspac[0] = motor_ident_B.Clock;
    motor_ident_B.TmpSignalConversionAtToWorkspac[1] =
      motor_ident_B.ManualSwitch;
    motor_ident_B.TmpSignalConversionAtToWorkspac[2] = motor_ident_B.theta;
    motor_ident_B.TmpSignalConversionAtToWorkspac[3] = motor_ident_B.TransferFcn;
  }
}

/* Model update function */
void motor_ident_update(void)
{
  if (rtmIsMajorTimeStep(motor_ident_M)) {
    rt_ertODEUpdateContinuousStates(&motor_ident_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++motor_ident_M->Timing.clockTick0)) {
    ++motor_ident_M->Timing.clockTickH0;
  }

  motor_ident_M->Timing.t[0] = rtsiGetSolverStopTime(&motor_ident_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.002s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++motor_ident_M->Timing.clockTick1)) {
      ++motor_ident_M->Timing.clockTickH1;
    }

    motor_ident_M->Timing.t[1] = motor_ident_M->Timing.clockTick1 *
      motor_ident_M->Timing.stepSize1 + motor_ident_M->Timing.clockTickH1 *
      motor_ident_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void motor_ident_derivatives(void)
{
  XDot_motor_ident_T *_rtXdot;
  _rtXdot = ((XDot_motor_ident_T *) motor_ident_M->ModelData.derivs);

  /* Derivatives for TransferFcn: '<S2>/theta_dot' */
  _rtXdot->theta_dot_CSTATE = 0.0;
  _rtXdot->theta_dot_CSTATE += motor_ident_P.theta_dot_A *
    motor_ident_X.theta_dot_CSTATE;
  _rtXdot->theta_dot_CSTATE += motor_ident_B.theta;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = 0.0;
  _rtXdot->TransferFcn_CSTATE += motor_ident_P.TransferFcn_A *
    motor_ident_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += motor_ident_B.ManualSwitch;
}

/* Model initialize function */
void motor_ident_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: motor_ident/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("qube_servo2_usb", "0", &motor_ident_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(motor_ident_DW.HILInitialize_Card,
      " ", 2);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(motor_ident_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      return;
    }

    if ((motor_ident_P.HILInitialize_set_analog_input_ && !is_switching) ||
        (motor_ident_P.HILInitialize_set_analog_inpu_a && is_switching)) {
      result = hil_set_analog_input_ranges(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILInitialize_analog_input_chan, 1U,
        &motor_ident_P.HILInitialize_analog_input_mini,
        &motor_ident_P.HILInitialize_analog_input_maxi);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if ((motor_ident_P.HILInitialize_set_analog_output && !is_switching) ||
        (motor_ident_P.HILInitialize_set_analog_outp_j && is_switching)) {
      result = hil_set_analog_output_ranges(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILInitialize_analog_output_cha, 1U,
        &motor_ident_P.HILInitialize_analog_output_min,
        &motor_ident_P.HILInitialize_analog_output_max);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if ((motor_ident_P.HILInitialize_set_analog_outp_n && !is_switching) ||
        (motor_ident_P.HILInitialize_set_analog_outp_c && is_switching)) {
      result = hil_write_analog(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILInitialize_analog_output_cha, 1U,
        &motor_ident_P.HILInitialize_initial_analog_ou);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if (motor_ident_P.HILInitialize_set_analog_out_cd) {
      result = hil_watchdog_set_analog_expiration_state
        (motor_ident_DW.HILInitialize_Card,
         &motor_ident_P.HILInitialize_analog_output_cha, 1U,
         &motor_ident_P.HILInitialize_watchdog_analog_o);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    result = hil_set_digital_directions(motor_ident_DW.HILInitialize_Card, NULL,
      0U, &motor_ident_P.HILInitialize_digital_output_ch, 1U);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(motor_ident_M, _rt_error_message);
      return;
    }

    if ((motor_ident_P.HILInitialize_set_digital_out_b && !is_switching) ||
        (motor_ident_P.HILInitialize_set_digital_out_i && is_switching)) {
      result = hil_write_digital(motor_ident_DW.HILInitialize_Card,
        &motor_ident_P.HILInitialize_digital_output_ch, 1U, (t_boolean *)
        &motor_ident_P.HILInitialize_initial_digital_o);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if (motor_ident_P.HILInitialize_set_digital_out_a) {
      result = hil_watchdog_set_digital_expiration_state
        (motor_ident_DW.HILInitialize_Card,
         &motor_ident_P.HILInitialize_digital_output_ch, 1U, (const
          t_digital_state *) &motor_ident_P.HILInitialize_watchdog_digital_);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if ((motor_ident_P.HILInitialize_set_encoder_param && !is_switching) ||
        (motor_ident_P.HILInitialize_set_encoder_par_n && is_switching)) {
      motor_ident_DW.HILInitialize_QuadratureModes[0] =
        motor_ident_P.HILInitialize_quadrature;
      motor_ident_DW.HILInitialize_QuadratureModes[1] =
        motor_ident_P.HILInitialize_quadrature;
      result = hil_set_encoder_quadrature_mode(motor_ident_DW.HILInitialize_Card,
        motor_ident_P.HILInitialize_encoder_channels, 2U,
        (t_encoder_quadrature_mode *)
        &motor_ident_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if ((motor_ident_P.HILInitialize_set_encoder_count && !is_switching) ||
        (motor_ident_P.HILInitialize_set_encoder_cou_b && is_switching)) {
      motor_ident_DW.HILInitialize_InitialEICounts[0] =
        motor_ident_P.HILInitialize_initial_encoder_c;
      motor_ident_DW.HILInitialize_InitialEICounts[1] =
        motor_ident_P.HILInitialize_initial_encoder_c;
      result = hil_set_encoder_counts(motor_ident_DW.HILInitialize_Card,
        motor_ident_P.HILInitialize_encoder_channels, 2U,
        &motor_ident_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if ((motor_ident_P.HILInitialize_set_other_outputs && !is_switching) ||
        (motor_ident_P.HILInitialize_set_other_outpu_b && is_switching)) {
      result = hil_write_other(motor_ident_DW.HILInitialize_Card,
        motor_ident_P.HILInitialize_other_output_chan, 3U,
        motor_ident_P.HILInitialize_initial_other_out);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }

    if (motor_ident_P.HILInitialize_set_other_outpu_d) {
      result = hil_watchdog_set_other_expiration_state
        (motor_ident_DW.HILInitialize_Card,
         motor_ident_P.HILInitialize_other_output_chan, 3U,
         motor_ident_P.HILInitialize_watchdog_other_ou);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for FromWorkspace: '<S4>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 10.0, 10.0, 20.0, 20.0, 30.0, 30.0,
      40.0, 40.0, 50.0, 50.0, 60.0, 60.0, 70.0, 70.0, 80.0, 80.0, 90.0, 90.0,
      100.0, 100.0, 110.0, 110.0, 120.0, 120.0, 130.0, 130.0, 140.0, 140.0,
      150.0, 150.0, 160.0, 160.0, 170.0, 170.0, 180.0, 180.0, 190.0, 190.0,
      200.0, 200.0, 210.0, 210.0, 220.0, 220.0, 230.0, 230.0, 240.0, 240.0,
      250.0, 250.0, 260.0, 260.0, 270.0, 270.0, 280.0, 280.0, 290.0, 290.0,
      300.0, 300.0, 310.0, 310.0, 320.0, 320.0, 330.0, 330.0, 340.0, 340.0,
      350.0, 350.0, 360.0, 360.0, 370.0, 370.0, 380.0, 380.0, 390.0, 390.0,
      400.0, 400.0, 410.0, 410.0, 420.0, 420.0, 430.0, 430.0, 440.0, 440.0,
      450.0, 450.0, 460.0, 460.0, 470.0, 470.0, 480.0, 480.0, 490.0, 490.0,
      500.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, -0.5, -0.5, 0.0, 0.0, 0.5, 0.5,
      0.0, 0.0, -1.0, -1.0, -0.0, -0.0, 1.0, 1.0, -0.0, -0.0, -1.5, -1.5, 0.0,
      0.0, 1.5, 1.5, 0.0, 0.0, -2.0, -2.0, -0.0, -0.0, 2.0, 2.0, 0.0, 0.0, -2.5,
      -2.5, 0.0, 0.0, 2.5, 2.5, 0.0, 0.0, -3.0, -3.0, -0.0, -0.0, 3.0, 3.0, 0.0,
      0.0, -3.5, -3.5, 0.0, 0.0, 3.5, 3.5, -0.0, -0.0, -4.0, -4.0, -0.0, -0.0,
      4.0, 4.0, -0.0, -0.0, -4.5, -4.5, 0.0, 0.0, 4.5, 4.5, 0.0, 0.0, -5.0, -5.0,
      0.0, 0.0, 5.0, 5.0, 0.0, 0.0, -5.0, -5.0, 0.0, 0.0, 5.0, 5.0, 2.0, 2.0,
      -2.0, -2.0, 2.0, 2.0, -2.0, -2.0, 1.0, 1.0, -1.0, -1.0 } ;

    motor_ident_DW.FromWs_PWORK.TimePtr = (void *) pTimeValues0;
    motor_ident_DW.FromWs_PWORK.DataPtr = (void *) pDataValues0;
    motor_ident_DW.FromWs_IWORK.PrevIndex = 0;
  }

  /* InitializeConditions for TransferFcn: '<S2>/theta_dot' */
  motor_ident_X.theta_dot_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn' */
  motor_ident_X.TransferFcn_CSTATE = 0.0;
}

/* Model terminate function */
void motor_ident_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: motor_ident/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_digital_outputs = 0;
    t_uint32 num_final_other_outputs = 0;
    hil_task_stop_all(motor_ident_DW.HILInitialize_Card);
    hil_monitor_stop_all(motor_ident_DW.HILInitialize_Card);
    is_switching = false;
    if ((motor_ident_P.HILInitialize_set_analog_outp_f && !is_switching) ||
        (motor_ident_P.HILInitialize_set_analog_outp_h && is_switching)) {
      num_final_analog_outputs = 1U;
    }

    if ((motor_ident_P.HILInitialize_set_digital_out_f && !is_switching) ||
        (motor_ident_P.HILInitialize_set_digital_out_g && is_switching)) {
      num_final_digital_outputs = 1U;
    }

    if ((motor_ident_P.HILInitialize_set_other_outp_bf && !is_switching) ||
        (motor_ident_P.HILInitialize_set_other_outp_bh && is_switching)) {
      num_final_other_outputs = 3U;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_digital_outputs > 0
        || num_final_other_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(motor_ident_DW.HILInitialize_Card
                         , &motor_ident_P.HILInitialize_analog_output_cha,
                         num_final_analog_outputs
                         , NULL, 0
                         , &motor_ident_P.HILInitialize_digital_output_ch,
                         num_final_digital_outputs
                         , motor_ident_P.HILInitialize_other_output_chan,
                         num_final_other_outputs
                         , &motor_ident_P.HILInitialize_final_analog_outp
                         , NULL
                         , (t_boolean *)
                         &motor_ident_P.HILInitialize_final_digital_out
                         , motor_ident_P.HILInitialize_final_other_outpu
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(motor_ident_DW.HILInitialize_Card,
            &motor_ident_P.HILInitialize_analog_output_cha,
            num_final_analog_outputs,
            &motor_ident_P.HILInitialize_final_analog_outp);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_digital_outputs > 0) {
          local_result = hil_write_digital(motor_ident_DW.HILInitialize_Card,
            &motor_ident_P.HILInitialize_digital_output_ch,
            num_final_digital_outputs, (t_boolean *)
            &motor_ident_P.HILInitialize_final_digital_out);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_other_outputs > 0) {
          local_result = hil_write_other(motor_ident_DW.HILInitialize_Card,
            motor_ident_P.HILInitialize_other_output_chan,
            num_final_other_outputs,
            motor_ident_P.HILInitialize_final_other_outpu);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(motor_ident_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(motor_ident_DW.HILInitialize_Card);
    hil_monitor_delete_all(motor_ident_DW.HILInitialize_Card);
    hil_close(motor_ident_DW.HILInitialize_Card);
    motor_ident_DW.HILInitialize_Card = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  motor_ident_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  motor_ident_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  motor_ident_initialize();
}

void MdlTerminate(void)
{
  motor_ident_terminate();
}

/* Registration function */
RT_MODEL_motor_ident_T *motor_ident(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)motor_ident_M, 0,
                sizeof(RT_MODEL_motor_ident_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&motor_ident_M->solverInfo,
                          &motor_ident_M->Timing.simTimeStep);
    rtsiSetTPtr(&motor_ident_M->solverInfo, &rtmGetTPtr(motor_ident_M));
    rtsiSetStepSizePtr(&motor_ident_M->solverInfo,
                       &motor_ident_M->Timing.stepSize0);
    rtsiSetdXPtr(&motor_ident_M->solverInfo, &motor_ident_M->ModelData.derivs);
    rtsiSetContStatesPtr(&motor_ident_M->solverInfo, (real_T **)
                         &motor_ident_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&motor_ident_M->solverInfo,
      &motor_ident_M->Sizes.numContStates);
    rtsiSetErrorStatusPtr(&motor_ident_M->solverInfo, (&rtmGetErrorStatus
      (motor_ident_M)));
    rtsiSetRTModelPtr(&motor_ident_M->solverInfo, motor_ident_M);
  }

  rtsiSetSimTimeStep(&motor_ident_M->solverInfo, MAJOR_TIME_STEP);
  motor_ident_M->ModelData.intgData.f[0] = motor_ident_M->ModelData.odeF[0];
  motor_ident_M->ModelData.contStates = ((real_T *) &motor_ident_X);
  rtsiSetSolverData(&motor_ident_M->solverInfo, (void *)
                    &motor_ident_M->ModelData.intgData);
  rtsiSetSolverName(&motor_ident_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = motor_ident_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    motor_ident_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    motor_ident_M->Timing.sampleTimes = (&motor_ident_M->
      Timing.sampleTimesArray[0]);
    motor_ident_M->Timing.offsetTimes = (&motor_ident_M->
      Timing.offsetTimesArray[0]);

    /* task periods */
    motor_ident_M->Timing.sampleTimes[0] = (0.0);
    motor_ident_M->Timing.sampleTimes[1] = (0.002);

    /* task offsets */
    motor_ident_M->Timing.offsetTimes[0] = (0.0);
    motor_ident_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(motor_ident_M, &motor_ident_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = motor_ident_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    motor_ident_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(motor_ident_M, 420.0);
  motor_ident_M->Timing.stepSize0 = 0.002;
  motor_ident_M->Timing.stepSize1 = 0.002;

  /* External mode info */
  motor_ident_M->Sizes.checksums[0] = (388095952U);
  motor_ident_M->Sizes.checksums[1] = (3356731593U);
  motor_ident_M->Sizes.checksums[2] = (2004675388U);
  motor_ident_M->Sizes.checksums[3] = (1061892183U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    motor_ident_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(motor_ident_M->extModeInfo,
      &motor_ident_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(motor_ident_M->extModeInfo,
                        motor_ident_M->Sizes.checksums);
    rteiSetTPtr(motor_ident_M->extModeInfo, rtmGetTPtr(motor_ident_M));
  }

  motor_ident_M->solverInfoPtr = (&motor_ident_M->solverInfo);
  motor_ident_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&motor_ident_M->solverInfo, 0.002);
  rtsiSetSolverMode(&motor_ident_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  motor_ident_M->ModelData.blockIO = ((void *) &motor_ident_B);
  (void) memset(((void *) &motor_ident_B), 0,
                sizeof(B_motor_ident_T));

  /* parameters */
  motor_ident_M->ModelData.defaultParam = ((real_T *)&motor_ident_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &motor_ident_X;
    motor_ident_M->ModelData.contStates = (x);
    (void) memset((void *)&motor_ident_X, 0,
                  sizeof(X_motor_ident_T));
  }

  /* states (dwork) */
  motor_ident_M->ModelData.dwork = ((void *) &motor_ident_DW);
  (void) memset((void *)&motor_ident_DW, 0,
                sizeof(DW_motor_ident_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    motor_ident_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 15;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  motor_ident_M->Sizes.numContStates = (2);/* Number of continuous states */
  motor_ident_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  motor_ident_M->Sizes.numY = (0);     /* Number of model outputs */
  motor_ident_M->Sizes.numU = (0);     /* Number of model inputs */
  motor_ident_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  motor_ident_M->Sizes.numSampTimes = (2);/* Number of sample times */
  motor_ident_M->Sizes.numBlocks = (17);/* Number of blocks */
  motor_ident_M->Sizes.numBlockIO = (9);/* Number of block outputs */
  motor_ident_M->Sizes.numBlockPrms = (82);/* Sum of parameter "widths" */
  return motor_ident_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
